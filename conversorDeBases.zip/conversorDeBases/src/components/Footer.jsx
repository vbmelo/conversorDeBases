

export default function Footer() {
    return (
        <footer className="footer">
            <h3>Footer</h3>
        </footer>
    );
}